ENT.Type = "anim"
ENT.Base = "base_nextbot"
ENT.PrintName = "Splinter Cell Operative"
ENT.Author = "AI Assistant"
ENT.Category = "NextBots"
ENT.Spawnable = true
ENT.AdminSpawnable = true

-- Model and properties
ENT.Model = "models/player/combine_super_soldier.mdl"
ENT.Health = 200
ENT.MaxHealth = 200
